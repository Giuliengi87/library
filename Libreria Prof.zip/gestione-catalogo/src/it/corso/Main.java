package it.corso;

import java.io.IOException;

import it.corso.Rivista.Periodico;

public class Main {
	
	public static void main(String[] args) throws IOException {
		
		Archivio archivio = new Archivio();
		
		
		archivio.caricamentoArchivio();
		
		
		Libro libro = new Libro(112, "Libro", 2001, 100, "Mario Rossi", "Commedia");
		archivio.addElement(libro);
		
		archivio.removeElement(112);
		
		libro = new Libro(113, "Libro", 2001, 100, "Mario Rossi", "Commedia");
		archivio.addElement(libro);
		
		libro = new Libro( 112, "Libro", 2001, 100, "Mario Rossi", "Commedia"  );
		archivio.addElement(libro);
		
		Rivista rivista = new Rivista( 111 , "Rivista", 2000, 50,  Periodico.MENSILE );
		archivio.addElement(libro);
		
		archivio.salvataggioArchivio();
		
		
		
		
	}
	
	
	
}
