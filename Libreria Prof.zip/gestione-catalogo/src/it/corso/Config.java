package it.corso;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Config {

	Properties prop;

	public Config() {
		prop = new Properties();
	}

	public String directoryLibri() throws IOException {

		FileInputStream file = new FileInputStream("src/config.properties");
		
		prop.load(file);
		
		String path = prop.getProperty("directoryLibri");

		return path;

	}

	public String directoryRiviste() throws IOException {

		FileInputStream file = new FileInputStream("src/config.properties");
		prop.load(file);
		String path = prop.getProperty("directoryRiviste");

		return path;

	}

}
