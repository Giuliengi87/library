package it.corso;

public class Libro extends Catalogo  {
	
	private String autore;
	private String genere;
	
	
	public Libro() {
		super();
	}

	Catalogo catalogo = new Catalogo();
	
	
	public Libro(int codiceISBN, String titolo, int annoPubblicazione, int numeroPagine,  String autore, String genere) {
		
		super( codiceISBN, titolo, annoPubblicazione, numeroPagine  );
		
		
		
		
		catalogo.setCodiceISBN(codiceISBN);
		catalogo.setTitolo(titolo);
		catalogo.setAnnoPubblicazione(annoPubblicazione);
		catalogo.setNumeroPagine(numeroPagine);
		
		
		this.autore = autore;
		this.genere = genere;
	}




	public String getAutore() {
		return autore;
	}




	public void setAutore(String autore) {
		this.autore = autore;
	}




	public String getGenere() {
		return genere;
	}




	public void setGenere(String genere) {
		this.genere = genere;
	}




	@Override
	public String toString() {
		return "Libro [autore=" + autore + ", genere=" + genere + ", getCodiceISBN()=" + getCodiceISBN()
				+ ", getTitolo()=" + getTitolo() + ", getAnnoPubblicazione()=" + getAnnoPubblicazione()
				+ ", getNumeroPagine()=" + getNumeroPagine() + "]";
	}




//	@Override
//	public String toString() {
//		return "Libro [autore=" + autore + ", genere=" + genere + ", catalogo=" + catalogo + ", getCodiceISBN()="
//				+ getCodiceISBN() + ", getTitolo()=" + getTitolo() + ", getAnnoPubblicazione()="
//				+ getAnnoPubblicazione() + ", getNumeroPagine()=" + getNumeroPagine() + "]";
//	}




	
	
}
