package it.corso;

public class Rivista extends Catalogo{
	
	public enum Periodico {
		SETTIMANALE,
		MENSILE,
		SEMESTRALE
	}
	
	private Periodico periodico;

	public Rivista(int codiceISBN, String titolo, int annoPubblicazione, int numeroPagine, Periodico periodico) {
		super(codiceISBN, titolo, annoPubblicazione, numeroPagine);
		
		this.periodico = periodico;
	}

	public Rivista() {
		super();
	}

	public Periodico getPeriodico() {
		return periodico;
	}

	public void setPeriodico(Periodico periodico) {
		this.periodico = periodico;
	}

	@Override
	public String toString() {
		return "Rivista [periodico=" + periodico + ", getCodiceISBN()=" + getCodiceISBN() + ", getTitolo()="
				+ getTitolo() + ", getAnnoPubblicazione()=" + getAnnoPubblicazione() + ", getNumeroPagine()="
				+ getNumeroPagine() + "]";
	}

	

	public void setPeriodico(String tipoPeriodico) {
		
		if ( tipoPeriodico.equalsIgnoreCase( "SETTIMANALE"   )  ) {
			
			this.periodico = periodico.SETTIMANALE;
			
		}else if ( tipoPeriodico.equalsIgnoreCase( "SEMESTRALE"   ) ) {
			this.periodico = periodico.SEMESTRALE;
		} else {
			this.periodico = periodico.MENSILE;
		}
		
	}
	
	
	
	
	
	
	
}
