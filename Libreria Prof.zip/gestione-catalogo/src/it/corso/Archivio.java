package it.corso;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Archivio {

	// Classe di configurazione
	Config conf;

	private List<Libro> listaLibri;
	private List<Rivista> listaRiviste;

	public Archivio() {
		super();

		conf = new Config();

		listaLibri = new ArrayList<Libro>();
		listaRiviste = new ArrayList<Rivista>();

	}

	public void addElement(Object obj) {

		// *************************** //
		//  Aggiunta Libro in Archivio //
		// *************************** //
		
		if (obj instanceof Libro) {
			
			Libro libro =  (Libro)obj; 
			
			Integer codiceISBN = libro.getCodiceISBN();
			
			Optional<Libro> trovatoLibro =   listaLibri.stream().filter( elemento -> elemento.getCodiceISBN() == codiceISBN ).findFirst();  
			
			if ( !trovatoLibro. isPresent() ) {
				
				listaLibri.add((Libro) obj);
				System.out.println("Aggiunto Libro: " + obj.toString());
				
			}else {
				System.out.println("Attenzione !! Libro gi� presente in archivio. Non inserito");
			}
		}
		
		
		
		// ***************************** //
		//  Aggiunta Rivista in Archivio //
		// ***************************** //

		if (obj instanceof Rivista) {
			
			Rivista rivista = (Rivista)obj;
			
			Optional<Rivista> trovataRivista =	listaRiviste.stream().filter(  elemento -> elemento.getCodiceISBN() == rivista.getCodiceISBN()  ).findFirst();
			
			if ( !trovataRivista.isPresent()  ) {
				listaRiviste.add((Rivista) obj);
				System.out.println("Aggiunta Rivista: " + obj.toString());
			}else {
				System.out.println( "Attenzione !! Rivista gi� presente in archivio. Non inserita" );
			}
			
			
		}

	}

	public void removeElement(int codiceISBN) {

		System.out.println("Rimozione elemento...");

		listaLibri.removeIf( elemento -> elemento.getCodiceISBN() == codiceISBN );

		listaRiviste.removeIf(elemento -> elemento.getCodiceISBN() == codiceISBN);

	}

	public void ricercaPerISBN(int codiceISBN) {

		// Cerco nei libri
		Optional<Libro> trovatoLibro = listaLibri.stream().filter( libro -> libro.getCodiceISBN() == codiceISBN )
										.findFirst();

		if (trovatoLibro.isPresent()) {
			Libro libro = trovatoLibro.get();
			System.out.println("Trovato Libro: " + libro.toString());
		}

		// Cerco nelle riviste
		Optional<Rivista> trovataRivista = listaRiviste.stream().filter(pippo -> pippo.getCodiceISBN() == codiceISBN)
											.findFirst();

		if (trovataRivista.isPresent()) {
			Rivista rivista = trovataRivista.get();
			
			System.out.println("Trovata Rivista: " + rivista.toString());
		}
	}

	public void ricercaPerAnnoPubblicazione(int annoPubblicazione) {

		List<Libro> trovatiLibri = listaLibri.stream()
							.filter(elemento -> elemento.getAnnoPubblicazione() == annoPubblicazione)
							.collect( Collectors.toList() );

		if (!trovatiLibri.isEmpty()) {
			trovatiLibri.stream().forEach(  System.out::println );
		}

		List<Rivista> trovateRiviste = listaRiviste.stream()
							.filter(elemento -> elemento.getAnnoPubblicazione() == annoPubblicazione)
							.collect(Collectors.toList());

		if (!trovateRiviste.isEmpty()) {
			trovateRiviste.stream().forEach(System.out::println);
		}

	}

	public void ricercaPerAutore(String autore) {

		List<Libro> trovatiLibri = listaLibri.stream()
									.filter(libro -> libro.getAutore().equals(autore))
									.collect(Collectors.toList());

		if (!trovatiLibri.isEmpty()) {
			trovatiLibri.stream().forEach(System.out::println);
		}

	}

	public void caricamentoArchivio() throws IOException {

		System.out.println("Caricamento dati da archivio ...");

		FileReader file;
		BufferedReader leggiFile;
		String rigaFile = "";

		
		// ****************** //
		// Caricamnto Libri   //
		// ****************** //
		String path = conf.directoryLibri();

		System.out.println(path);

		File mioFile = new File(path);

		if (!mioFile.exists()) {

			System.out.println("il file non esiste !! Verifica la directory e/o il nome del file");

		} else {

			try {

				System.out.println("Inizio Caricamento Libri ...");

				leggiFile = new BufferedReader(new FileReader(mioFile));

				while (true) {

					rigaFile = leggiFile.readLine();

					if (rigaFile == null)
						break;

					System.out.println(rigaFile);

					aggiungiLibroAllaLista( rigaFile);
				}

			} catch (FileNotFoundException e) {

				e.printStackTrace();

			}

			System.out.println("Caricamento Libri Terminato con successo !!");
		}
		
		
		// ****************** //
		// Caricamnto Riviste //
		// ****************** //
		path = conf.directoryRiviste();

		System.out.println(path);

		mioFile = new File(path);

		if (!mioFile.exists()) {

			System.out.println("il file non esiste !! Verifica la directory e/o il nome del file");

		} else {

			try {

				System.out.println("Inizio Caricamento Riviste ...");

				leggiFile = new BufferedReader(new FileReader(mioFile));

				while (true) {

					rigaFile = leggiFile.readLine();

					if (rigaFile == null)
						break;

					System.out.println(rigaFile);

					aggiungiRivistaAllaLista(rigaFile);
				}

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			System.out.println("Caricamento Riviste Terminato con successo !! ");
		}
	}

	
	
	
	private void aggiungiRivistaAllaLista(String riga) {

		if (riga == null)
			return;

		Rivista rivista = new Rivista();

		// Struttura riga
		// 1111|"titolo"|2000|200|"SEMESTRALE"| 

		String[] elemento = riga.split("[|]");

		List<String> fixedList = Arrays.asList(elemento);

		ArrayList<String> listOfString = new ArrayList<String>(fixedList);

		rivista.setCodiceISBN(Integer.parseInt(listOfString.get(0)));
		rivista.setTitolo(listOfString.get(1));
		rivista.setAnnoPubblicazione(Integer.parseInt(listOfString.get(2)));
		rivista.setNumeroPagine(Integer.parseInt(listOfString.get(3)));

		rivista.setPeriodico(listOfString.get(4));

		listaRiviste.add(rivista);

		System.out.println("Aggiunta rivista: " + rivista.toString() + " alla lista");

	}

	private void aggiungiLibroAllaLista(String riga) {

		System.out.println("Riga letta da file �: " + riga);
		

		Libro libro = new Libro();
		
		// struttura riga //
		// 1111|"titolo"|2000|200|"Mario Rossi"|"commedia"| 

		String[] elemento = riga.split("[|]");

		List<String> fixedList = Arrays.asList(elemento);

		ArrayList<String> listOfString = new ArrayList<String>(fixedList);

		libro.setCodiceISBN(Integer.parseInt(listOfString.get(0)));
		libro.setTitolo(listOfString.get(1));
		libro.setAnnoPubblicazione(Integer.parseInt(listOfString.get(2)));
		libro.setNumeroPagine(Integer.parseInt(listOfString.get(3)));

		libro.setAutore(listOfString.get(4));
		libro.setGenere(listOfString.get(5));

		listaLibri.add(libro);

		System.out.println("Aggiunto libro: " + libro.toString() + " alla lista");

	}

	public void salvataggioArchivio() throws IOException {

		
		// *********************** //
		// ** Salvataggio libri ** //
		// *********************** //
		
		String path = conf.directoryLibri();

		File f = new File(path);
		FileWriter fop = new FileWriter(f);

		try {

			for (Libro libro : listaLibri) {

				// Attenzione !! aggiungo gli apici perch� quando si instanzia da main l'oggetto
				// Libro o Rivista
				// il cast da obj a Libro o Rivista non aggiunge i doppi apici ' " ' ai campi
				// Stringa ...
				// lo salvo con gli apici

				fop.write( libro.getCodiceISBN() + "|");
				fop.write( libro.getTitolo()  + "|");
				fop.write( libro.getAnnoPubblicazione() + "|");
				fop.write( libro.getNumeroPagine() + "|");
				fop.write( libro.getAutore() + "|");
				fop.write( libro.getGenere() + "|");
				fop.write("\n");

			}
			fop.close();

		} catch (IOException e1) {
			e1.printStackTrace();
		}

		System.out.println("Salvati Libri !!");

		
		
		// ************************** //
		// ** Salvataggio riviste ** //
		// ************************* //
		path = conf.directoryRiviste();

		f = new File(path);

		fop = new FileWriter(f);

		try {

			// Attenzione !! aggiungo gli apici perch� quando si instanzia da main l'oggetto
			// Libro o Rivista
			// il cast da obj a Libro o Rivista non aggiunge gli apici "" ai campi Stringa
			// ...
			// lo salvo con gli apici

			for (Rivista rivista : listaRiviste) {

				fop.write(rivista.getCodiceISBN() + "|");

				fop.write( rivista.getTitolo()  + "|");

				fop.write(rivista.getAnnoPubblicazione() + "|");
				fop.write(rivista.getNumeroPagine() + "|");
				fop.write(rivista.getPeriodico() + "|");

				fop.write("\n"); // manda a capo la riga dopo averla scritta

			}
			fop.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Salvate Riviste !!");
		
		System.out.println( "** Fine Programma **" );
		
	}
	
	

}
